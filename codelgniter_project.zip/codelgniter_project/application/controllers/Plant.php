<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH. 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Plant extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('plant_model');
        $this->load->database();
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        $this->load->view('frontent/header');
        $this->load->view('frontent/sidebar');
        $data['records'] = $this->plant_model->get_customers();
        $this->load->view('company/plant_view', $data);
        $this->load->view('frontent/footer');
    }

    public function savedata() {
        $customer_data = array(
            'Company' => $this->input->post('Company'),
            'Plant_Name' => $this->input->post('Plant_Name'),
            'Alias_Name' => $this->input->post('Alias_Name'),
            'Address1' => $this->input->post('Address1'),
            'Address2' => $this->input->post('Address2'),
            'Postal_Code' => $this->input->post('Postal_Code'),
            'City' => $this->input->post('City'),
            'Region' => $this->input->post('Region'),
            'Currency' => $this->input->post('Currency'),
            'Plant_Code' => $this->input->post('Plant_Code'),
            'Country' => $this->input->post('Country'),

        );
        $this->plant_model->save_customer($customer_data);
        redirect('Plant');
    }

   
    public function edit($id) {
      
        $data['record'] = $this->plant_model->get_customer($id);
        $this->load->view('company/edit2', $data);
    }

    public function update($id) {
        $updated_data = array(
            'Company' => $this->input->post('Company'),
            'Plant_Name' => $this->input->post('Plant_Name'),
            'Alias_Name' => $this->input->post('Alias_Name'),
            'Address1' => $this->input->post('Address1'),
            'Address2' => $this->input->post('Address2'),
            'Postal_Code' => $this->input->post('Postal_Code'),
            'City' => $this->input->post('City'),
            'Region' => $this->input->post('Region'),
            'Currency' => $this->input->post('Currency'),
            'Plant_Code' => $this->input->post('Plant_Code'),
            'Country' => $this->input->post('Country'),
        );

        $this->plant_model->update_customer($id, $updated_data);
        redirect('Plant');
    }

   
    public function delete($id) { 
        $this->load->model('plant_model');
        $response=$this->plant_model->delete_customer($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Plant').'";</script>';
        } else {
            echo '<script>alert(" Deleted!"); window.location.href="'.base_url('Plant').'";</script>';
        }
 
}
      
}
?>

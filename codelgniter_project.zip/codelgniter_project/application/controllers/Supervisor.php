<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH. 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Supervisor extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('supervisor_model');
        $this->load->database();
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        $this->load->view('frontent/header');
        $this->load->view('frontent/sidebar');
        $data['records'] = $this->supervisor_model->get_customers();
        $this->load->view('company/supervisor_view', $data);
        $this->load->view('frontent/footer');
    }

    public function savedata() {
        $customer_data = array(
            'Company_Name' => $this->input->post('Company_Name'),
            'Plant_Name' => $this->input->post('Plant_Name'),
            'Sales_Organisation_Name' => $this->input->post('Sales_Organisation_Name'),
            'Supervisor_Code' => $this->input->post('Supervisor_Code'),
            'Employee_Code' => $this->input->post('Employee_Code'),
            'Supervisor_Name' => $this->input->post('Supervisor_Name'),
            'Street' => $this->input->post('Street'),
            'Address' => $this->input->post('Address'),
            'Postal_Code' => $this->input->post('Postal_Code'),
            'Mobile_Number' => $this->input->post('Mobile_Number'),
            'City' => $this->input->post('City'),
            'Region' => $this->input->post('Region'),
            'Country' => $this->input->post('Country'),
            'User_Name' => $this->input->post('User_Name'),
            'Password' => $this->input->post('Password'),
            'Confirm_Password' => $this->input->post('Confirm_Password'),
            'Status' => $this->input->post('Status'),
            'ERP_ID' => $this->input->post('ERP_ID')

        );  
        // echo "<pre>";
        // print_r($customer_data );
        // exit;
        $this->supervisor_model->save_customer($customer_data);
        redirect('Supervisor');
    }

   
    public function edit($id) {
      
        $data['record'] = $this->supervisor_model->get_customer($id);
        $this->load->view('company/edit5', $data);
    }

    public function update($id) {
        $updated_data = array(
            'Company_Name' => $this->input->post('Company_Name'),
            'Plant_Name' => $this->input->post('Plant_Name'),
            'Sales_Organisation_Name' => $this->input->post('Sales_Organisation_Name'),
            'Supervisor_Code' => $this->input->post('Supervisor_Code'),
            'Employee_Code' => $this->input->post('Employee_Code'),
            'Supervisor_Name' => $this->input->post('Supervisor_Name'),
            'Street' => $this->input->post('Street'),
            'Address' => $this->input->post('Address'),
            'Postal_Code' => $this->input->post('Postal_Code'),
            'Mobile_Number' => $this->input->post('Mobile_Number'),
            'City' => $this->input->post('City'),
            'Region' => $this->input->post('Region'),
            'Country' => $this->input->post('Country'),
            'User_Name' => $this->input->post('User_Name'),
            'Password' => $this->input->post('Password'),
            'Confirm_Password' => $this->input->post('Confirm_Password'),
            'Status' => $this->input->post('Status'),
            'ERP_ID' => $this->input->post('ERP_ID')
        );

        $this->supervisor_model->update_customer($id, $updated_data);
        redirect('Supervisor');
    }

   
    public function delete($id) { 
        $this->load->model('supervisor_model');
        $response=$this->supervisor_model->delete_customer($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Supervisor').'";</script>';
        } else {
            echo '<script>alert(" Deleted!"); window.location.href="'.base_url('Supervisor').'";</script>';
        }
 
}
      
public function data(){
    $data= $this->data['records'] = $this->supervisor_model->get_customers();
    //  print_r($data);
    //  exit;  
    if(count($data)>0){
        $spreadsheet = new Spreadsheet();
        $sheet=$spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1','Company_Name');
        $sheet->setCellValue('B1','Plant_Name');
        $sheet->setCellValue('C1','Sales_Organisation_Name');
        $sheet->setCellValue('D1','Supervisor_Code');
        $sheet->setCellValue('E1','Employee_Code	');
        $sheet->setCellValue('F1','Supervisor_Name');
        $sheet->setCellValue('G1','Street');
        $sheet->setCellValue('H1','Address');
        $sheet->setCellValue('I1','Postal_Code	');
        $sheet->setCellValue('J1','Mobile_Number');
        $sheet->setCellValue('K1','City');
        $sheet->setCellValue('L1','Region');
        $sheet->setCellValue('M1','Country');
        $sheet->setCellValue('N1','User_Name');
        $sheet->setCellValue('O1','Password');
        $sheet->setCellValue('P1','Confirm_Password');
        $sheet->setCellValue('Q1','Status');
        $sheet->setCellValue('R1','ERP_ID');
        
        // $sheet->getStyle('A1:AE1')->getFont()->setBold(true);
        
        $row=2;

        foreach($data as $datas){

            $sheet->setCellValue('A'.$row, $datas['Company_Name']);
            $sheet->setCellValue('B'.$row, $datas['Plant_Name']);
            $sheet->setCellValue('C'.$row, $datas['Sales_Organisation_Name']);
            $sheet->setCellValue('D'.$row, $datas['Supervisor_Code']);
            $sheet->setCellValue('E'.$row, $datas['Employee_Code']);
            $sheet->setCellValue('F'.$row, $datas['Supervisor_Name']);
            $sheet->setCellValue('G'.$row, $datas['Street']);
            $sheet->setCellValue('H'.$row, $datas['Address']);
            $sheet->setCellValue('I'.$row, $datas['Postal_Code']);
            $sheet->setCellValue('J'.$row, $datas['Mobile_Number']);
            $sheet->setCellValue('K'.$row, $datas['City']);
            $sheet->setCellValue('L'.$row, $datas['Region']);
            $sheet->setCellValue('M'.$row, $datas['Country']);
            $sheet->setCellValue('N'.$row, $datas['User_Name']);
            $sheet->setCellValue('O'.$row, $datas['Password']);
            $sheet->setCellValue('P'.$row, $datas['Confirm_Password']);
            $sheet->setCellValue('Q'.$row, $datas['Status']);
            $sheet->setCellValue('R'.$row, $datas['ERP_ID']);
                  $row++;
        }
           $writer=new Csv($spreadsheet);
           $filename="demo";
           header('Content-type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
           header('Content-Disposition:attachment;filename='.$filename.'.csv');
           header('Cache-Control:max-age=0');
           $writer->save('php://output');
    }else{
         echo 'no data exported';
    }
}

}
?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH. 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Vehicle extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('vehicle_model');
        $this->load->database();
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        $this->load->view('frontent/header');
        $this->load->view('frontent/sidebar');
        $data['records'] = $this->vehicle_model->get_customers();
        $this->load->view('company/vehicle_view', $data);
        $this->load->view('frontent/footer');
    }

    public function savedata() {
        $customer_data = array(
            'Vehicle_Code' => $this->input->post('Vehicle_Code'),
            'Vehicle_No' => $this->input->post('Vehicle_No'),
            'Vehicle_Name' => $this->input->post('Vehicle_Name'),
            'Capacity' => $this->input->post('Capacity'),
            'Status' => $this->input->post('Status')
        );
        $this->vehicle_model->save_customer($customer_data);
        redirect('Vehicle');
    }

   
    public function edit($id) {
        $data['record'] = $this->vehicle_model->get_customer($id);
        $this->load->view('company/edit6', $data);
    }

    public function update($id) {
        $updated_data = array(
            'Vehicle_Code' => $this->input->post('Vehicle_Code'),
            'Vehicle_No' => $this->input->post('Vehicle_No'),
            'Vehicle_Name' => $this->input->post('Vehicle_Name'),
            'Capacity' => $this->input->post('Capacity'),
            'Status' => $this->input->post('Status')
        );

        $this->vehicle_model->update_customer($id, $updated_data);
        redirect('Vehicle');
    }

   
    public function delete($id) { 
        $this->load->model('vehicle_model');
        $response=$this->vehicle_model->delete_customer($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Vehicle').'";</script>';
        } else {
            echo '<script>alert(" Deleted!"); window.location.href="'.base_url('Vehicle').'";</script>';
        }
 
}
      
}
?>

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH. 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Tray extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('tray_model');
        $this->load->database();
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        $this->load->view('frontent/header');
        $this->load->view('frontent/sidebar');
        $data['records'] = $this->tray_model->get_customers();
        $this->load->view('company/tray_view', $data);
        $this->load->view('frontent/footer');
    }

    public function savedata() {
        $customer_data = array(
            'Company' => $this->input->post('Company'),
            'Sales_Area' => $this->input->post('Sales_Area'),
            'Tray_Code' => $this->input->post('Tray_Code'),
            'Tray_Description' => $this->input->post('Tray_Description'),
            'Type' => $this->input->post('Type'),
            'Capacity' => $this->input->post('Capacity')
        );
        $this->tray_model->save_customer($customer_data);
        redirect('Tray');
    }

   
    public function edit($id) {
        $data['record'] = $this->tray_model->get_customer($id);
        $this->load->view('company/edit7', $data);
    }

    public function update($id) {
        $updated_data = array(
            'Company' => $this->input->post('Company'),
            'Sales_Area' => $this->input->post('Sales_Area'),
            'Tray_Code' => $this->input->post('Tray_Code'),
            'Tray_Description' => $this->input->post('Tray_Description'),
            'Type' => $this->input->post('Type'),
            'Capacity' => $this->input->post('Capacity')
        );

        $this->tray_model->update_customer($id, $updated_data);
        redirect('Tray');
    }

   
    public function delete($id) { 
        $this->load->model('tray_model');
        $response=$this->tray_model->delete_customer($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Tray').'";</script>';
        } else {
            echo '<script>alert(" Deleted!"); window.location.href="'.base_url('Tray').'";</script>';
        }
 
}
      
}
?>

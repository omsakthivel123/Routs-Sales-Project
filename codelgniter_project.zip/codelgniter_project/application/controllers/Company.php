<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH. 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Company extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('company_model');
        $this->load->database();
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        $this->load->view('frontent/header');
        $this->load->view('frontent/sidebar');
        $data['records'] = $this->company_model->get_customers();
        $this->load->view('company/company_view', $data);
        $this->load->view('frontent/footer');
    }

    public function savedata() {
        $customer_data = array(
            'Company_Code' => $this->input->post('Company_Code'),
            'Company_Name' => $this->input->post('Company_Name'),
            'Currency' => $this->input->post('Currency'),
            'City' => $this->input->post('City'),
            'Country' => $this->input->post('Country'),
        );
        $this->company_model->save_customer($customer_data);
        redirect('Company');
    }

   
    public function edit($id) {
        $data['record'] = $this->company_model->get_customer($id);
        $this->load->view('company/edit', $data);
    }

    public function update($id) {
        $updated_data = array(
            'Company_Code' => $this->input->post('Company_Code'),
            'Company_Name' => $this->input->post('Company_Name'),
            'Currency' => $this->input->post('Currency'),
            'City' => $this->input->post('City'),
            'Country' => $this->input->post('Country')
        );

        $this->company_model->update_customer($id, $updated_data);
        redirect('Company');
    }

   
    public function delete($id) { 
        $this->load->model('company_model');
        $response=$this->company_model->delete_customer($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Company').'";</script>';
        } else {
            echo '<script>alert(" Deleted!"); window.location.href="'.base_url('Company').'";</script>';
        }
 
}
      
}
?>

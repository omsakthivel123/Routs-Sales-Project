<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH. 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


class Customer extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('customer_model');
        $this->load->database();
        // $this->load->helper( 'url');
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        $this->load->view('frontent/header');
        $this->load->view('frontent/sidebar');
        $data['records'] = $this->customer_model->get_customers();
        $this->load->view('customer_view', $data);
        $this->load->view('frontent/footer');
    }

    public function savedata() {
        $customer_data = array(
            'Company_Name' => $this->input->post('Company_Name'),
            'Plant_Name' => $this->input->post('Plant_Name'),
            'Sales_Org_Name' => $this->input->post('Sales_Org_Name'),
            'Sales_Area_Name' => $this->input->post('Sales_Area_Name'),
            'Customer_Code' => $this->input->post('Customer_Code'),
            'Customer_Name' => $this->input->post('Customer_Name'),
            'Customer_Profile' => $this->input->post('Customer_Profile'),
            'Street_house_number' => $this->input->post('Street_house_number'),
            'Postal_code' => $this->input->post('Postal_code'),
            'City' => $this->input->post('City'),
            'Region' => $this->input->post('Region'),
            'Country' => $this->input->post('Country'),
            'Price_List' => $this->input->post('Price_List'),
            'GST_Number' => $this->input->post('GST_Number'),
            'Phone_number' => $this->input->post('Phone_number'),
            'Contact_Person' => $this->input->post('Contact_Person'),
            'Mobile_number' => $this->input->post('Mobile_number'),
            'E_mail_ID' => $this->input->post('E_mail_ID'),
            'ASM_Name' => $this->input->post('ASM_Name'),
            'ASO_Name' => $this->input->post('ASO_Name'),
            'Bank_IFSC_Code' => $this->input->post('Bank_IFSC_Code'),
            'Bank_Account_Number' => $this->input->post('Bank_Account_Number'),
            'Account_Holder_Name' => $this->input->post('Account_Holder_Name'),
            'Status' => $this->input->post('Status'),
            'Loyalty_Type' => $this->input->post('Loyalty_Type'),
            'Scheme_Discount' => $this->input->post('Scheme_Discount'),
            'Slab' => $this->input->post('Slab'),
            'ERP_ID' => $this->input->post('ERP_ID'),
            'Latitude' => $this->input->post('Latitude'),
            'Longitude' => $this->input->post('Longitude'),
        );
        $this->customer_model->save_customer($customer_data);
        redirect('customer');
    }

   
    public function edit($id) {
        $data['record'] = $this->customer_model->get_customer($id);
        $this->load->view('edit', $data);
    }

    public function update($id) {
        $updated_data = array(
            'Sales_Area_Name' => $this->input->post('Sales_Area_Name'),
            'ERP_ID' => $this->input->post('ERP_ID'),
            'Customer_Code' => $this->input->post('Customer_Code'),
            'Customer_Name' => $this->input->post('Customer_Name'),
            'Price_List' => $this->input->post('Price_List'),
            'Phone_number' => $this->input->post('Phone_number'),
            'Status' => $this->input->post('Status'),
        );

        $this->customer_model->update_customer($id, $updated_data);
        redirect('customer');
    }

   
    public function delete($id) { 
        $this->load->model('Customer_model');
        $response=$this->Customer_model->delete_customer($id);
        if($response) { 
            echo '<script>alert("Deleted!"); window.location.href="'.base_url('Customer').'";</script>';
        } else {
            echo '<script>alert(" Deleted!"); window.location.href="'.base_url('Customer').'";</script>';
        }
 
}
       
// public function download() {

//     $this->load->dbutil();
//     $this->load->database();
//     $this->load->helper('file');
//     $this->load->helper('download');
//     $query = $this->db->query("SELECT * FROM vijay_project");
//     $delimiter = ",";
//     $newline = "\r\n";
//     $data = $this->dbutil->csv_from_result($query, $delimiter, $newline);
//     force_download('UserList.csv', $data);
// }

public function data(){
    $data= $this->data['records'] = $this->customer_model->get_customers();
    //  print_r($data);
    //  exit;  
    if(count($data)>0){
        $spreadsheet = new Spreadsheet();
        $sheet=$spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1','So_Code');
        $sheet->setCellValue('B1','Company_Name');
        $sheet->setCellValue('C1','Plant_Name');
        $sheet->setCellValue('D1','Sales_Org_Name');
        $sheet->setCellValue('E1','Sales_Area_Name	');
        $sheet->setCellValue('F1','Customer_Code');
        $sheet->setCellValue('G1','Customer_Name');
        $sheet->setCellValue('H1','Customer_Profile');
        $sheet->setCellValue('I1','Street_house_number	');
        $sheet->setCellValue('J1','Postal_code');
        $sheet->setCellValue('K1','City');
        $sheet->setCellValue('L1','Region');
        $sheet->setCellValue('M1','Country');
        $sheet->setCellValue('N1','Price_List');
        $sheet->setCellValue('O1','GST_Number');
        $sheet->setCellValue('P1','Phone_number');
        $sheet->setCellValue('Q1','Contact_Person');
        $sheet->setCellValue('R1','Mobile_number');
        $sheet->setCellValue('S1','E_mail_ID');
        $sheet->setCellValue('T1','ASM_Name');
        $sheet->setCellValue('U1','ASO_Name	');
        $sheet->setCellValue('V1','Bank_IFSC_Code');
        $sheet->setCellValue('W1','Bank_Account_Number');
        $sheet->setCellValue('X1','Account_Holder_Name');
        $sheet->setCellValue('Y1','Status	');
        $sheet->setCellValue('Z1','Loyalty_Type');
        $sheet->setCellValue('AA1','Scheme_Discount	');
        $sheet->setCellValue('AB1','Slab');
        $sheet->setCellValue('AC1','ERP_ID');
        $sheet->setCellValue('AD1','Latitude');
        $sheet->setCellValue('AE1','Longitude');
        // $sheet->getStyle('A1:AE1')->getFont()->setBold(true);
        
        $row=2;

        foreach($data as $datas){

            $sheet->setCellValue('A'.$row, $datas['So_Code']);
            $sheet->setCellValue('B'.$row, $datas['Company_Name']);
            $sheet->setCellValue('C'.$row, $datas['Plant_Name']);
            $sheet->setCellValue('D'.$row, $datas['Sales_Org_Name']);
            $sheet->setCellValue('E'.$row, $datas['Sales_Area_Name']);
            $sheet->setCellValue('F'.$row, $datas['Customer_Code']);
            $sheet->setCellValue('G'.$row, $datas['Customer_Name']);
            $sheet->setCellValue('H'.$row, $datas['Customer_Profile']);
            $sheet->setCellValue('I'.$row, $datas['Street_house_number']);
            $sheet->setCellValue('J'.$row, $datas['Postal_code']);
            $sheet->setCellValue('K'.$row, $datas['City']);
            $sheet->setCellValue('L'.$row, $datas['Region']);
            $sheet->setCellValue('M'.$row, $datas['Country']);
            $sheet->setCellValue('N'.$row, $datas['Price_List']);
            $sheet->setCellValue('O'.$row, $datas['GST_Number']);
            $sheet->setCellValue('P'.$row, $datas['Phone_number']);
            $sheet->setCellValue('Q'.$row, $datas['Contact_Person']);
            $sheet->setCellValue('R'.$row, $datas['Mobile_number']);
            $sheet->setCellValue('S'.$row, $datas['E_mail_ID']);
            $sheet->setCellValue('T'.$row, $datas['ASM_Name']);
            $sheet->setCellValue('U'.$row, $datas['ASO_Name']);
            $sheet->setCellValue('V'.$row, $datas['Bank_IFSC_Code']);
            $sheet->setCellValue('W'.$row, $datas['Bank_Account_Number']);
            $sheet->setCellValue('X'.$row, $datas['Account_Holder_Name']);
            $sheet->setCellValue('Y'.$row, $datas['Status']);
            $sheet->setCellValue('Z'.$row, $datas['Loyalty_Type']);
            $sheet->setCellValue('AA'.$row, $datas['Scheme_Discount']);
            $sheet->setCellValue('AB'.$row, $datas['Slab']);
            $sheet->setCellValue('AC'.$row, $datas['ERP_ID']);
            $sheet->setCellValue('AD'.$row, $datas['Latitude']);
            $sheet->setCellValue('AE'.$row, $datas['Longitude']);
      $row++;
        }
           $writer=new Csv($spreadsheet);
           $filename="demo";
           header('Content-type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
           header('Content-Disposition:attachment;filename='.$filename.'.csv');
           header('Cache-Control:max-age=0');
           $writer->save('php://output');
    }else{
         echo 'no data exported';
    }
}

public function import_data() {
    if(isset($_FILES['file']) && is_uploaded_file($_FILES['file']['tmp_name'])){
        // Upload file
        $config['upload_path'] = 'Uploads';
        $config['allowed_types'] = 'csv|xlsx|xls';
        $config['max_size'] = '2000';
        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('file')){
            // Read uploaded file
            $file_data = $this->upload->data();
            $inputFileName = $file_data['full_path'];
            $inputFileType = \PhpOffice\PhpSpreadsheet\IOFactory::identify($inputFileName);
            $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($inputFileType);
            $spreadsheet = $reader->load($inputFileName);
            $sheet = $spreadsheet->getActiveSheet();

            // Iterate through rows and insert data
foreach ($sheet->getRowIterator() as $row) {
    $rowData = $row->getRowIndex();
    if ($rowData == 1) continue;
    $data = array(
        
        'Company_Name' => $sheet->getCell('A' . $rowData)->getValue(),
        'Plant_Name' => $sheet->getCell('B' . $rowData)->getValue(),
        'Sales_Org_Name' => $sheet->getCell('C' . $rowData)->getValue(),
        'Sales_Area_Name' => $sheet->getCell('D' . $rowData)->getValue(),
        'Customer_Code' => $sheet->getCell('E' . $rowData)->getValue(),
        'Customer_Name' => $sheet->getCell('F' . $rowData)->getValue(),
        'Customer_Profile' => $sheet->getCell('G' . $rowData)->getValue(),
        'Street_house_number' => $sheet->getCell('H' . $rowData)->getValue(),
        'Postal_code' => $sheet->getCell('I' . $rowData)->getValue(),
        'City' => $sheet->getCell('J' . $rowData)->getValue(),
        'Region' => $sheet->getCell('K' . $rowData)->getValue(),
        'Country' => $sheet->getCell('L' . $rowData)->getValue(),
        'Price_List' => $sheet->getCell('M' . $rowData)->getValue(),
        'GST_Number' => $sheet->getCell('N' . $rowData)->getValue(),
        'Phone_number' => $sheet->getCell('O' . $rowData)->getValue(),
        'Contact_Person' => $sheet->getCell('P' . $rowData)->getValue(),
        'Mobile_number' => $sheet->getCell('Q' . $rowData)->getValue(),
        'E_mail_ID' => $sheet->getCell('R' . $rowData)->getValue(),
        'ASM_Name' => $sheet->getCell('S' . $rowData)->getValue(),
        'ASO_Name' => $sheet->getCell('T' . $rowData)->getValue(),
        'Bank_IFSC_Code' => $sheet->getCell('U' . $rowData)->getValue(),
        'Bank_Account_Number' => $sheet->getCell('V' . $rowData)->getValue(),
        'Account_Holder_Name' => $sheet->getCell('W' . $rowData)->getValue(),
        'Status' => $sheet->getCell('X' . $rowData)->getValue(),
        'Loyalty_Type' => $sheet->getCell('Y' . $rowData)->getValue(),
        'Scheme_Discount' => $sheet->getCell('Z' . $rowData)->getValue(),
        'Slab' => $sheet->getCell('AA' . $rowData)->getValue(),
        'ERP_ID' => $sheet->getCell('AB' . $rowData)->getValue(),
        'Latitude' => $sheet->getCell('AC' . $rowData)->getValue(),
        'Longitude' => $sheet->getCell('AD' . $rowData)->getValue(),

    );
    // foreach ($row->getCellIterator() as $cell) {
    //     $data[] = $cell->getValue();
    $this->customer_model->insert_data($data);

            }
            echo "<script>alert('Data imported successfully!'); window.location.href='".base_url('customer')."';</script>";
        } else {
            echo $this->upload->display_errors();
        }
    } else {
        echo "No file uploaded!";
    }
}


}
?>

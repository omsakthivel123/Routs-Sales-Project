<?php
 class Index extends CI_Controller{

    public function index()
	{
		$this->load->view('home');

	}

	public function task(){

		print_r("hii");
	}
}



?>
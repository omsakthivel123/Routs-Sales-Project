<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH. 'vendor/autoload.php'; 

use PhpOffice\PhpSpreadsheet\Reader\Csv as ReaderCsv;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
UserName
class Price_upload extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('price_upload_model');
        $this->load->database();
        $this->load->helper(array('form', 'url'));
    }

    public function index() {
        $this->load->view('frontent/header');
        $this->load->view('frontent/sidebar');
        $data['records'] = $this->price_upload_model->get_customers();
        $this->load->view('company/price_upload_view', $data);
        $this->load->view('frontent/footer');
    }

    public function savedata() {
        $customer_data = array(
            'Company_code' => $this->input->post('Company_code'),
            'Plant_code' => $this->input->post('Plant_code'),
            'Salesorg_code' => $this->input->post('Salesorg_code'),
            'Price_list' => $this->input->post('Price_list'),
            'Material_code' => $this->input->post('Material_code'),
            'Amount' => $this->input->post('Amount'),
            'Valid_from' => $this->input->post('Valid_from'),
            'Valid_to' => $this->input->post('Valid_to'),
            'Status' => $this->input->post('Status'),
            'Tax' => $this->input->post('Tax'),
            'Tax_value' => $this->input->post('Tax_value'),
            'Net_price' => $this->input->post('Net_price')
        );
        $this->price_upload_model->save_customer($customer_data);
        redirect('Price_upload');
    }

   
    public function edit($id) {
        $data['record'] = $this->price_upload_model->get_customer($id);
        $this->load->view('company/edit8', $data);
    }

    public function update($id) {
        $updated_data = array(
            'Company_code' => $this->input->post('Company_code'),
            'Plant_code' => $this->input->post('Plant_code'),
            'Salesorg_code' => $this->input->post('Salesorg_code'),
            'Price_list' => $this->input->post('Price_list'),
            'Material_code' => $this->input->post('Material_code'),
            'Amount' => $this->input->post('Amount'),
            'Valid_from' => $this->input->post('Valid_from'),
            'Valid_to' => $this->input->post('Valid_to'),
            'Status' => $this->input->post('Status'),
            'Tax' => $this->input->post('Tax'),
            'Tax_value' => $this->input->post('Tax_value'),
            'Net_price' => $this->input->post('Net_price')
        );

        $this->price_upload_model->update_customer($id, $updated_data);
        redirect('Price_upload');
    }

    public function data(){
        $data= $this->data['records'] = $this->price_upload_model->get_customers();
        //  print_r($data);
        //  exit;  
        if(count($data)>0){
            $spreadsheet = new Spreadsheet();
            $sheet=$spreadsheet->getActiveSheet();
            $sheet->setCellValue('A1','Company_code');
            $sheet->setCellValue('B1','Plant_code');
            $sheet->setCellValue('C1','Salesorg_code');
            $sheet->setCellValue('D1','Price_list');
            $sheet->setCellValue('E1','Material_code	');
            $sheet->setCellValue('F1','Amount');
            $sheet->setCellValue('G1','Valid_from');
            $sheet->setCellValue('H1','Valid_to');
            $sheet->setCellValue('I1','Status	');
            $sheet->setCellValue('J1','Tax');
            $sheet->setCellValue('K1','Tax_value');
          
            
            // $sheet->getStyle('A1:AE1')->getFont()->setBold(true);
            
            $row=2;
    
            foreach($data as $datas){
    
                $sheet->setCellValue('A'.$row, $datas['Company_code']);
                $sheet->setCellValue('B'.$row, $datas['Plant_code']);
                $sheet->setCellValue('C'.$row, $datas['Salesorg_code']);
                $sheet->setCellValue('D'.$row, $datas['Price_list']);
                $sheet->setCellValue('E'.$row, $datas['Material_code']);
                $sheet->setCellValue('F'.$row, $datas['Amount']);
                $sheet->setCellValue('G'.$row, $datas['Valid_from']);
                $sheet->setCellValue('H'.$row, $datas['Valid_to']);
                $sheet->setCellValue('I'.$row, $datas['Status']);
                $sheet->setCellValue('J'.$row, $datas['Tax']);
                $sheet->setCellValue('K'.$row, $datas['Tax_value']);
          $row++;
            }
               $writer=new Csv($spreadsheet);
               $filename="demo";
               header('Content-type:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
               header('Content-Disposition:attachment;filename='.$filename.'.csv');
               header('Cache-Control:max-age=0');
               $writer->save('php://output');
        }else{
             echo 'no data exported';
        }
    }
 


public function import_data() {
    if(isset($_FILES['file']) && is_uploaded_file($_FILES['file']['tmp_name'])){
        // Upload file
        $config['upload_path'] = 'Uploads';
        $config['allowed_types'] = 'csv|xlsx|xls';
        $config['max_size'] = '2000';
        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if($this->upload->do_upload('file')){
            // Read uploaded file
            $file_data = $this->upload->data();
            $inputFileName = $file_data['full_path'];
            $inputFileType = \PhpOffice\PhpSpreadsheet\IOFactory::identify($inputFileName);
            $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($inputFileType);
            $spreadsheet = $reader->load($inputFileName);
            $sheet = $spreadsheet->getActiveSheet();

            // Iterate through rows and insert data
foreach ($sheet->getRowIterator() as $row) {
    $rowData = $row->getRowIndex();
    if ($rowData == 1) continue;
    $data = array(
        
        'Company_code' => $sheet->getCell('A' . $rowData)->getValue(),
        'Plant_code' => $sheet->getCell('B' . $rowData)->getValue(),
        'Salesorg_code' => $sheet->getCell('C' . $rowData)->getValue(),
        'Price_list' => $sheet->getCell('D' . $rowData)->getValue(),
        'Material_code' => $sheet->getCell('E' . $rowData)->getValue(),
        'Amount' => $sheet->getCell('F' . $rowData)->getValue(),
        'Valid_from' => $sheet->getCell('G' . $rowData)->getValue(),
        'Valid_to' => $sheet->getCell('H' . $rowData)->getValue(),
        'Status' => $sheet->getCell('I' . $rowData)->getValue(),
        'Tax' => $sheet->getCell('J' . $rowData)->getValue(),
        'Tax_value' => $sheet->getCell('K' . $rowData)->getValue(),
        'Net_price' => $sheet->getCell('L' . $rowData)->getValue()
    );
    // foreach ($row->getCellIterator() as $cell) {
    //     $data[] = $cell->getValue();
    $this->price_upload_model->insert_data($data);

            }
            echo "<script>alert('Data imported successfully!'); window.location.href='".base_url('Price_upload')."';</script>";
        } else {
            echo $this->upload->display_errors();
        }
    } else {
        echo "No file uploaded!";
    }
}




}
?>

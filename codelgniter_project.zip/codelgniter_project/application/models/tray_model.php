<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class tray_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_customers() {
        $query = $this->db->get('tray');
        return $query->result_array();
    }

    public function save_customer($data) {
        $this->db->insert('tray', $data);
    }
    public function get_customer($id) {
        $query = $this->db->get_where('tray', array('Id' => $id));
        return $query->row_array();
    }

    public function update_customer($id, $data) {
        $this->db->where('Id', $id);
        $this->db->update('tray', $data);
    }

    public function delete_customer($id) {
        $this->db->where('Id', $id);
        $this->db->delete('tray');
    }

    
    // public function insert_data($data) {
    //     $this->db->insert('vijay_project', $data);
    //     if ($this->db->affected_rows() > 0) {
    //         return true; 
    //     } else {
    //         return false; 
    //     }
    // }
}
?>


































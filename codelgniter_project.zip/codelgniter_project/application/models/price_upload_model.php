<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class price_upload_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function get_customers() {
        $query = $this->db->get(' price_upload');
        return $query->result_array();
    }

    public function save_customer($data) {
        $this->db->insert(' price_upload', $data);
    }
    public function get_customer($id) {
        $query = $this->db->get_where(' price_upload', array('Id' => $id));
        return $query->row_array();
    }

    public function update_customer($id, $data) {
        $this->db->where('Id', $id);
        $this->db->update(' price_upload', $data);
    }

    public function delete_customer($id) {
        $this->db->where('Id', $id);
        $this->db->delete(' price_upload');
    }

    
    public function insert_data($data) {
        $this->db->insert('price_upload', $data);
        if ($this->db->affected_rows() > 0) {
            return true; 
        } else {
            return false; 
        }
    }
}
?>


































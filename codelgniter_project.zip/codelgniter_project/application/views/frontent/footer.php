<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page with Footer</title>
    <!-- Bootstrap CSS -->
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->
</head>
<style>

</style>
<body>


<footer class="hello">
<div class="container-fluid  bg-lite " style="height: 18vh; width: 114.9%;" >
<div class="col-md-12">
       
            <div  style="text-align:center ; margin-top:60px;"  >
              2016 &copy; Application Developed by <a href="http://scoto.in/"  target="_new" >Scoto Systec</a>
              <a href="#" class="go-top">
                  <i class="icon-angle-up"></i>
              </a>
          </div>

            </div>
        </div>

</footer>
    </div></div></div>
<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>
</body> 
</html>

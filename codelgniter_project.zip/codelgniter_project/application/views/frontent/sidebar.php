<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navigation Bar</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<style>
        /* Style for the fixed sidebar */
        .page-sidebar-inner.slimscroll {
            overflow-y: auto; /* Add vertical scrollbar to the sidebar */
            max-height: calc(100vh - 90px); /* Set maximum height for the sidebar */
        }

        .sidebar {
            position: fixed;
            top: 107px; /* Match the height of the navbar */
            left: 0;
            width: 220px;
            background-color: #002E6E;
            padding-top: 10px;
            transition: width 0.3s ease;
            z-index: 1030; /* Ensure the sidebar appears above the content */
        }

        .page-sidebar-inner .menu .nav-link {
            font-size: 16px; /* Change the font size as needed */
            border-bottom: 1px solid #ccc; /* Add border bottom to each menu item */
            display: block;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
        }

        .menu .nav-link:hover {
            background-color: #555;
        }

        .menu {
            background: #002E6E !important;
            color: white !important;
        }

        .submenu {
            display: none;
            margin-left: 20px;
        }

        .menu > li:hover .submenu {
            display: block;
        }

        .submenu li {
            padding: 10px;
        }

        .submenu li a {
            color: #ccc;
            text-decoration: none;
        }

        .submenu li a:hover {
            color: white;
        }

        .content {
            margin-left: 250px; /* Same as the sidebar width */
            padding: 20px;
            overflow: auto; /* Add overflow for content */
        }
    </style>
</head>
<body>

<div class="page-sidebar sidebar page-header-fixed  pace-done compact-menu">
    <div class="page-sidebar-inner slimscroll">
        <ul class="menu accordion-menu">
            <li>
                <a href="" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-home"></span>
                    <p class="text-white">Dashboard</p>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-globe"></span>
                    <p>Org. Master</p>
                </a>
                <ul class="submenu">
                    <li><a href="<?= base_url('Company/index/') ?>">Company</a></li>
                    <li><a href="<?= base_url('Plant/index/') ?>">Plant</a></li>
                    <li><a href="<?= base_url('Sales_orgni/index/') ?>">Sales Organization</a></li>
                    <li><a href="<?= base_url('Sales_Area/index/') ?>">Sales Area</a></li>
                    <li><a href="<?= base_url('Supervisor/index/') ?>">Supervisor</a></li>
                    <!-- <li><a href="<?= base_url('Supervisor/index/') ?>">Material</a></li> -->
                    <!-- <li><a href="#">Price</a></li> -->
                    <li><a href="<?= base_url('Tray/index/') ?>">Tray</a></li>
                    <li><a href="<?= base_url('Vehicle/index/') ?>">Vehicle</a></li>
                    <li><a href="#">Bill Header Settings Mobile</a></li>
                    <li><a href="#">Bill Header Settings Web</a></li>
                    <li><a href="<?= base_url('Price_upload/index/') ?>">Price Upload</a></li>

                </ul>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon fa fa-users fa-5x"></span>
                    <p>Customer</p>
                </a>
                <ul class="submenu">
                    <li><a href="<?= base_url('Customer/index/') ?>" >Add Customer</a></li>
                    <li><a href="#">Customer Profile</a></li>
                    <li><a href="#">Customer Accounts</a></li>
                    <li><a href="#">Loyalty Card</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-gift"></span>
                    <p>Loyalty</p>
                </a>
                <ul class="submenu">
                    <li><a href="#">Scheme</a></li>
                    <li><a href="#">Cash Discount</a></li>
                    <li><a href="#">Cashback</a></li>
                    <li><a href="#">Without Slab</a></li>
                    <li><a href="#">With Slab</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-list-alt"></span>
                    <p>Billing Log</p>
                </a>
                <ul class="submenu">
                    <li><a href="#">Invoice List</a></li>
                    <li><a href="#">Cancel Bill</a></li>
                    <li><a href="#">Payment Received</a></li>
                    <li><a href="#">Return and Expiry</a></li>
                    <li><a href="#">Update Payment</a></li>
                    <li><a href="#">Update Return</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-shopping-cart"></span>
                    <p>Transactions</p>
                </a>
                <ul class="submenu">
                    <!-- Sub-menu items here -->
                </ul>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-file"></span>
                    <p>Reports</p>
                </a>
                <ul class="submenu">
                    <li><a href="#">Sales Report</a></li>
                    <li><a href="#">Material Report</a></li>
                    <li><a href="#">Customer Report</a></li>
                </ul>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-user"></span>
                    <p>User Management</p>
                </a>
            </li>
            <li>
                <a href="#" class="nav-link">
                    <span class="menu-icon glyphicon glyphicon-log-in"></span>
                    <p>Log out</p>
                </a>
            </li>
        </ul>
    </div><!-- Page Sidebar Inner -->
</div><!-- Page Sidebar -->

<div class="content">
    <!-- Your content goes here -->
</div>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

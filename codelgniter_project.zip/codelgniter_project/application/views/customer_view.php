<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VIJAY_PROJECT</title>
    <!-- <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"> -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->

    <style>
      .hi{
            margin-left:100px;
 
        }
        .text{

            margin-left:100px;

            /* height: 10vh;
             width: 5%;  */
        }
        .hello{
            margin-bottom: 1px;
        }
        /* .testing{
            margin-left:200px;
          
        } */
       /* .sak{
        text-size-adjust: 8;
       } */

    </style>

<body>  

<div class="container">
    <div class="row">
        <div class="col-mad-12">

<div class="hi">
<div class="container-fluid bg-white" style="height: 5vh; width: 100%;  ">
<div class="container bg-light p-3 rounded"> 
        <div class="d-flex justify-content-between align-items-center">
            <a class="navbar-brand text-lite" href="#" >
                <h5 class="text-dark"style="margin-top: 5px; ">Customer Details</h5>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent"></div>
       
        <div class="d-flex justify-content-end" class="hello">
            <a href="<?= base_url('Customer/data/') ?>" type="button" class="btn btn-danger mr-2">Download Data</a>
            <button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target="#customerModal">+ Add New</button>
            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#uploadModal">+ Upload</button>
        </div></div></div>
    </div> </div><br><br>


<div class="modal fade" id="customerModal" tabindex="-1" role="dialog" aria-labelledby="customerModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="customerModalLabel">Add Customer</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form  method="post" action="<?= base_url('Customer/savedata'); ?>">
                  
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="Company_Name">Company Name*</label>
                                    <select class="form-control" id="Company_Name" name="Company_Name">
                                    <option value="Selecet Company">Selecet Company</option>
                                    <option value="Vijay Home Foods TRICHY(VHFTRY)">Vijay Home Foods TRICHY(VHFTRY)</option>
                                    <option value="Vijay Home Foods (P) LTD(VHF)">Vijay Home Foods (P) LTD(VHF)</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="Plant_Name">Plant Name*</label>
                                    <input type="text" class="form-control" id="Plant_Name" name="Plant_Name">
                                </div>
                                <!-- Other form fields -->
                                <div class="form-group">
                                <label for="Sales_Org_Name">Sales Org Name*</label>
                                <input type="text" class="form-control" id="Sales_Org_Name" name="Sales_Org_Name">
                            </div>
                            <div class="form-group">
                                <label for="Sales_Area_Name">Sales_Area_Name*</label>
                                <input type="text" class="form-control" id="Sales_Area_Name" name="Sales_Area_Name">
                            </div>
                            <div class="form-group">
                                <label for="Customer_Code">Customer Code</label>
                                <input type="text" class="form-control" id="Customer_Code" name="Customer_Code">
                            </div>
                            <div class="form-group">
                                <label for="Customer_Name">Customer Name*</label>
                                <input type="text" class="form-control" id="Customer_Name" name="Customer_Name">
                            </div>
                            <div class="form-group">
                                <label for="Customer_Profile">Customer Profile</label>
                                <input type="file" class="form-control-file" id="Customer_Profile" name="Customer_Profile">
                            </div>

                            <div class="form-group">
                                <label for="Street_house_number">Street_house number*</label>
                                <input type="text" class="form-control" id="Street_house_number" name="Street_house_number">
                            </div>
                            <div class="form-group">
                                <label for="Postal_code">Postal code</label>
                                <input type="text" class="form-control" id="Postal_code" name="Postal_code">
                            </div>
                            <div class="form-group">
                                <label for="City">City*</label>
                                <input type="text" class="form-control" id="City" name="City">
                            </div>
                            <div class="form-group">
                                <label for="Region">Region*</label>
                                <input type="text" class="form-control" id="Region" name="Region">
                            </div>
                            <div class="form-group">
                                <label for="Country">Country</label>
                                <input type="text" class="form-control" id="Country" name="Country">
                            </div>
                            <div class="form-group">
                                <label for="Price_List">Price List</label>
                                <input type="text" class="form-control" id="Price_List" name="Price_List">
                            </div>
                            <div class="form-group">
                                <label for="GST_Number">GST Number</label>
                                <input type="text" class="form-control" id="GST_Number" name="GST_Number">
                            </div>
                            <div class="form-group">
                                <label for="Phone_number">Phone number*</label>
                                <input type="text" class="form-control" id="Phone_number" name="Phone_number">
                            </div>
                            </div>
                        
                            <div class="col-md-6">

                              
                         
                            <div class="form-group">
                                <label for="Contact_Person">Contact Person</label>
                                <input type="text" class="form-control" id="Contact_Person" name="Contact_Person">
                            </div>
                            <div class="form-group">
                                <label for="Mobile_number">Mobile number</label>
                                <input type="text" class="form-control" id="Mobile_number" name="Mobile_number">
                            </div>
                            <div class="form-group">
                                <label for="E_mail_ID">E-mail ID*</label>
                                <input type="text" class="form-control" id="E_mail_ID" name="E_mail_ID">
                            </div>
                            <div class="form-group">
                                <label for="ASM_Name">ASM Name</label>
                                <input type="text" class="form-control" id="ASM_Name" name="ASM_Name">
                            </div>
                            <div class="form-group">
                                <label for="ASO_Name">ASO Name</label>
                                <input type="text" class="form-control" id="ASO_Name" name="ASO_Name">
                            </div>
                            <div class="form-group">
                                <label for="Bank_IFSC_Code">Bank IFSC Code</label>
                                <input type="text" class="form-control" id="Bank_IFSC_Code" name="Bank_IFSC_Code">
                            </div>
                            <div class="form-group">
                                <label for="Bank_Account_Number">Bank Account Number</label>
                                <input type="text" class="form-control" id="Bank_Account_Number" name="Bank_Account_Number">
                            </div>
                            <div class="form-group">
                                <label for="Account_Holder_Name">Account Holder Name</label>
                                <input type="text" class="form-control" id="Account_Holder_Name" name="Account_Holder_Name">
                            </div>
                            <!-- <div class="col-md-6"> -->
                                <div class="form-group">
                                    <label for="Status">Status</label>
                                    <select class="form-control" id="Status" name="Status">
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                </div>
                                <!-- Other form fields -->
                                <div class="form-group">
                                <label for="Loyalty_Type">Loyalty Type</label>
                                <input type="text" class="form-control" id="Loyalty_Type" name="Loyalty_Type">
                            </div>    
                            <div class="form-group">
                                <label for="Scheme_Discount">Scheme_Discount</label>
                                <input type="text" class="form-control" id="Scheme_Discount" name="Scheme_Discount">
                            </div>  
                            <div class="form-group">
                                <label for="lab">Slab</label>
                                <input type="text" class="form-control" id="Slab" name="Slab">
                            </div>
                            <div class="form-group">
                                <label for="ERP_ID">ERP ID</label>
                                <input type="text" class="form-control" id="ERP_ID" name="ERP_ID">
                            </div> 
                            <div class="form-group">
                                <label for="Latitude">Latitude</label>
                                <input type="text" class="form-control" id="Latitude" name="Latitude">
                            </div>
                            <div class="form-group">
                                <label for="Longitude">Longitude</label>
                                <input type="text" class="form-control" id="Longitude" name="Longitude">
                            </div> 
                            <div class="modal-footer">
                                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                 <button type="submit" class="btn btn-primary">Submit</button>
                            </div>   
                  
                            </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <!-- <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div> -->
        



     <!-- Upload Modal -->
     <div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Upload File</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= base_url('Customer/import_data'); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="file">Select File:</label>
                            <input type="file" class="form-control-file" id="file" name="file">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Upload </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<div class="row">


<div class="text">
    <div class="container-fluid text-white p-4" style="height: 10vh; width: 100%;">
        <div class="container bg-light p-3 rounded">
            <!-- <h2 class="text-center mb-4">Customer Details</h2> -->
            <table id="dataTable" class="table table-striped table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th class="text-center">Id</th>
                        <th class="text-center">So Code</th>
                        <th class="text-center">Route Name</th>
                        <th class="text-center">ERPID</th>
                        <th class="text-center">Customer Code</th>
                        <th class="text-center">Customer Name</th>
                        <th class="text-center">Price Code</th>
                        <th class="text-center">Phone Num</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>  
                <tbody>
                    <?php 
                    $i = 1;
                    if (isset($records) && !empty($records)): ?>
                        <?php foreach ($records as $record): ?> 
                            <tr>
                                <td class="text-center"><?= $record['Id'] ?></td>
                                <td class="text-center"><?= $record['So_Code'] ?></td>
                                <td class="text-center"><?= $record['Sales_Area_Name'] ?></td>
                                <td class="text-center"><?= $record['ERP_ID'] ?></td>
                                <td class="text-center"><?= $record['Customer_Code'] ?></td>
                                <td class="text-center"><?= $record['Customer_Name'] ?></td>
                                <td class="text-center"><?= $record['Price_List'] ?></td>
                                <td class="text-center"><?= $record['Phone_number'] ?></td>
                                <td class="text-center"><?= $record['Status'] ?></td>
                                <td class="text-center">
                                    <a href="<?= base_url('Customer/edit/'.$record['Id']) ?>" class="btn btn-success btn-sm">Edit</a>
                                    <a href="<?= base_url('Customer/delete/'.$record['Id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?> 
                    <?php else: ?>
                        <tr><td colspan="10" class="text-center">No records found</td></tr>
                    <?php endif; ?>
                </tbody> 
            </table></div>
    </div>
</div>
</div>
<br><br><br>

<!-- 
<footer>
<div class="container-fluid bg-danger " style="height: 9vh; width: 114.9%;" >
<div class="col-md-12">
       
            <div class="sak" style="text-align:center; margin-top:20px;"  >
              2016 &copy; Application Developed by <a href="http://scoto.in/"  target="_new" >Scoto Systec</a>
              <a href="#" class="go-top">
                  <i class="icon-angle-up"></i>
              </a>
          </div>

            </div>
        </div>

</footer>
    </div></div></div>   -->


    




    

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script> -->
<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script> -->

    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });
    </script>
    <script>
        $(document).ready(function(){
            $('#file').click(function(){
                $('#uploadModal').modal('show');
            });
        });
    </script>

</body>
</html>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Record</h2>
        <div class="modal-body">
            <form action="<?= site_url('Customer/update/'.$record['Id']) ?>" method="post">
                         <div class="form-group"> 
                                <label for="Sales_Area_Name">Sales_Area_Name*</label>
                                <input type="text" class="form-control" id="Sales_Area_Name" name="Sales_Area_Name"value="<?= $record['Sales_Area_Name'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="ERP_ID">ERP ID</label>
                                <input type="text" class="form-control" id="ERP_ID" name="ERP_ID" value="<?= $record['ERP_ID'] ?>">
                            </div> 
                            <div class="form-group">
                                <label for="Customer_Code">Customer Code</label>
                                <input type="text" class="form-control" id="Customer_Code" name="Customer_Code" value="<?= $record['Customer_Code'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="Customer_Name">Customer Name*</label>
                                <input type="text" class="form-control" id="Customer_Name" name="Customer_Name"value="<?= $record['Customer_Name'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="Price_List">Price List</label>
                                <input type="text" class="form-control" id="Price_List" name="Price_List"value="<?= $record['Price_List'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="Phone_number">Phone number*</label>
                                <input type="text" class="form-control" id="Phone_number" name="Phone_number"value="<?= $record['Phone_number'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="Status">Status</label>
                                <input type="text" class="form-control" id="Status" name="Status"value="<?= $record['Status'] ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                
                         <!-- <button type="submit" class="btn btn-primary" name="update">Update</button> -->
            </form>
        </div>
    </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


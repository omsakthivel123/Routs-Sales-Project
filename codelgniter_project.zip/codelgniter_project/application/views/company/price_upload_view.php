<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VIJAY_PROJECT</title>
    <!-- <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet"> -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->

    <style>
      .hi{
            margin-left:100px;
 
        }
        .text{

            margin-left:100px;
        }
        .hello{
            margin-bottom: 1px;
        }
    </style>

<body>  

<div class="container">
    <div class="row">
        <div class="col-mad-12">

<div class="hi">
<div class="container-fluid bg-white" style="height: 5vh; width: 100%;  ">
<div class="container bg-light p-3 rounded"> 
        <div class="d-flex justify-content-between align-items-center">
            <a class="navbar-brand text-lite" href="#" >
                <h5 class="text-dark"style="margin-top: 5px; ">Price_upload Details</h5>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent"></div>
       
        <div class="d-flex justify-content-end" class="hello">
            <button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target="#customerModal">+ Add New</button>
        </div></div></div>
    </div> </div><br><br>


    <div class="modal fade" id="customerModal" tabindex="-1" role="dialog" aria-labelledby="customerModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="customerModalLabel">Add Company</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="companyForm" method="post" action="<?= base_url('Price_upload/savedata'); ?>">
                    <div class="form-group">
                        <label for="Company_code">Company_code</label>
                        <input type="text" class="form-control" id="Company_code" name="Company_code">
                    </div> 
                    <div class="form-group">
                        <label for="Plant_code">Plant_code</label>
                        <input type="text" class="form-control" id="Plant_code" name="Plant_code">
                    </div>
                    <div class="form-group">
                        <label for="Salesorg_code">Salesorg_code</label>
                        <input type="Address" class="form-control" id="Salesorg_code" name="Salesorg_code">
                    </div>
                    <div class="form-group">
                        <label for="Price_list">Price_list </label>
                        <input type="Address" class="form-control" id="Price_list" name="Price_list">
                    </div> 
                    <div class="form-group">
                        <label for="Material_code">Material_code </label>
                        <input type="Address" class="form-control" id="Material_code" name="Material_code">
                    </div> 
                    <div class="form-group">
                        <label for="Amount">Amount</label>
                        <input type="text" class="form-control" id="Amount" name="Amount">
                    </div>
                    <div class="form-group">
                        <label for="Valid_from">Valid_from</label>
                        <input type="Address" class="form-control" id="Valid_from" name="Valid_from">
                    </div>
                    <div class="form-group">
                        <label for="Valid_to">Valid_to </label>
                        <input type="Address" class="form-control" id="Valid_to" name="Valid_to">
                    </div> 
                    <div class="form-group">
                        <label for="Status">Status </label>
                        <input type="Address" class="form-control" id="Status" name="Status">
                    </div> 
                    <div class="form-group">
                        <label for="Tax">Tax</label>
                        <input type="text" class="form-control" id="Tax" name="Tax">
                    </div>
                    <div class="form-group">
                        <label for="Tax_value">Tax_value</label>
                        <input type="Address" class="form-control" id="Tax_value" name="Tax_value">
                    </div>
                    <div class="form-group">
                        <label for="Net_price">Net_price </label>
                        <input type="Address" class="form-control" id="Net_price" name="Net_price">
                    </div> 
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>   
                </form>
            </div>
        </div>
    </div>
</div>



<div class="row">
<div class="text">
    <div class="container-fluid text-white p-4" style="height: 10vh; width: 100%;">
    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#uploadModal">+ Upload</button>
    <a href="<?= base_url('Customer/data/') ?>" type="button" class="btn btn-danger mr-2">Upload Format </a>
    </div>
    </div>
    </div>

    <div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Upload File</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= base_url('Price_upload/import_data'); ?>" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="file">Select File:</label>
                            <input type="file" class="form-control-file" id="file" name="file">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Upload </button>
                    </form>
                </div>
            </div>
        </div>
    </div>


<div class="row">
<div class="text">
    <div class="container-fluid text-white p-4" style="height: 10vh; width: 100%;">
        <div class="container bg-light p-3 rounded">
            <!-- <h2 class="text-center mb-4">Customer Details</h2> -->
            <table id="dataTable" class="table table-striped table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th class="text-center">Id</th>
                        <th class="text-center">Company_code </th>
                        <th class="text-center">Plant_code</th>
                        <th class="text-center">Salesorg_code </th>
                        <th class="text-center">Price_list </th>
                        <th class="text-center">Material_code</th>
                        <th class="text-center">Amount</th>
                        <th class="text-center">Valid_from</th>
                 
                        <th class="text-center">Net_price</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>  
                <tbody>
                    <?php 
                    $i = 1;
                    if (isset($records) && !empty($records)): ?>
                        <?php foreach ($records as $record): ?> 
                            <tr>
                                <td class="text-center"><?= $record['Id'] ?></td>
                                <td class="text-center"><?= $record['Company_code'] ?></td>
                                <td class="text-center"><?= $record['Plant_code'] ?></td>
                                <td class="text-center"><?= $record['Salesorg_code'] ?></td>
                                <td class="text-center"><?= $record['Price_list'] ?></td>
                                <td class="text-center"><?= $record['Material_code'] ?></td>
                                <td class="text-center"><?= $record['Amount'] ?></td>
                                <td class="text-center"><?= $record['Valid_from'] ?></td>
                             
                                <td class="text-center"><?= $record['Net_price'] ?></td>
                                <td class="text-center">
                                    <a href="<?= base_url('Price_upload/edit/'.$record['Id']) ?>" class="btn btn-success btn-sm">Edit</a>
                                    <a href="<?= base_url('Price_upload/delete/'.$record['Id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?> 
                    <?php else: ?>
                        <tr><td colspan="10" class="text-center">No records found</td></tr>
                    <?php endif; ?>
                </tbody> 
            </table></div>
    </div>
</div>
</div>
<br><br><br>




    




    

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script> -->
<!-- <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script> -->

    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });
    </script>
    <script>
        $(document).ready(function(){
            $('#file').click(function(){
                $('#uploadModal').modal('show');
            });
        });
    </script>



</body>
</html>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Record</h2>
        <div class="modal-body">
            <form action="<?= base_url('Sales_orgni/update/'.$record['Id']) ?>" method="post">
                     <div class="form-group">
                        <label for="Company_Name">Company *</label>
                        <select class="form-control" id="Company_Name" name="Company_Name" value="<?= $record['Company_Name'] ?>">
                            <option value="Selecet Company">Selecet Company</option>
                            <option value="Vijay Home Foods TRICHY(VHFTRY)">Vijay Home Foods TRICHY(VHFTRY)</option>
                            <option value="Vijay Home Foods (P) LTD(VHF)">Vijay Home Foods (P) LTD(VHF)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="Plant_Name">Plant_Name </label>
                        <input type="text" class="form-control" id="Plant_Name" name="Plant_Name" value="<?= $record['Plant_Name'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Sales_Organisation_Code">Sales_Organisation_Code</label>
                        <input type="text" class="form-control" id="Sales_Organisation_Code" name="Sales_Organisation_Code" value="<?= $record['Sales_Organisation_Code'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Sales_Organisation_Name">Sales_Organisation_Name</label>
                        <input type="text" class="form-control" id="Sales_Organisation_Name" name="Sales_Organisation_Name" value="<?= $record['Sales_Organisation_Name'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Address">Address</label>
                        <input type="Address" class="form-control" id="Address" name="Address" value="<?= $record['Address'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Alias_Name">Alias_Name </label>
                        <input type="Address" class="form-control" id="Alias_Name" name="Alias_Name" value="<?= $record['Alias_Name'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Address">Address</label>
                        <input type="text" class="form-control" id="Address" name="Address" value="<?= $record['Address'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Postal_Code">Postal_Code</label>
                        <input type="text" class="form-control" id="Postal_Code" name="Postal_Code" value="<?= $record['Postal_Code'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="City">City</label>
                        <input type="text" class="form-control" id="City" name="City" value="<?= $record['City'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Region">Region</label>
                        <input type="text" class="form-control" id="Region" name="Region" value="<?= $record['Region'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Country">Country</label>
                        <input type="text" class="form-control" id="Country" name="Country" value="<?= $record['Country'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Currency">Currency</label>
                        <input type="text" class="form-control" id="Currency" name="Currency" value="<?= $record['Currency'] ?>">
                    </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                
                         <!-- <button type="submit" class="btn btn-primary" name="update">Update</button> -->
            </form>
        </div>
    </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


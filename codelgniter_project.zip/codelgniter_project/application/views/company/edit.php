<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Record</h2>
        <div class="modal-body">
            <form action="<?= base_url('Company/update/'.$record['Id']) ?>" method="post">
                         <div class="form-group"> 
                                <label for="Company_Code">Company_Code*</label>
                                <input type="text" class="form-control" id="Company_Code" name="Company_Code"value="<?= $record['Company_Code'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="Company_Name">Company_Name </label>
                                <input type="text" class="form-control" id="Company_Name" name="Company_Name" value="<?= $record['Company_Name'] ?>">
                            </div> 
                            <div class="form-group">
                                <label for="Currency">Currency </label>
                                <input type="text" class="form-control" id="Currency" name="Currency" value="<?= $record['Currency'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="City">City *</label>
                                <input type="text" class="form-control" id="City" name="City"value="<?= $record['City'] ?>">
                            </div>
                            <div class="form-group">
                                <label for="Country"> Country*</label>
                                <input type="text" class="form-control" id="Country" name="Country"value="<?= $record['Country'] ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                
                         <!-- <button type="submit" class="btn btn-primary" name="update">Update</button> -->
            </form>
        </div>
    </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


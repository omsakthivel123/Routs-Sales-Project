<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Record</h2>
        <div class="modal-body">
            <form action="<?= base_url('Price_upload/update/'.$record['Id']) ?>" method="post">
                    <div class="form-group">
                        <label for="Company_code">Company_code</label>
                        <input type="text" class="form-control" id="Company_code" name="Company_code" value="<?= $record['Company_code'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Plant_code">Plant_code</label>
                        <input type="text" class="form-control" id="Plant_code" name="Plant_code" value="<?= $record['Plant_code'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Salesorg_code">Salesorg_code</label>
                        <input type="Address" class="form-control" id="Salesorg_code" name="Salesorg_code" value="<?= $record['Salesorg_code'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Price_list">Price_list </label>
                        <input type="Address" class="form-control" id="Price_list" name="Price_list" value="<?= $record['Price_list'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Material_code">Material_code </label>
                        <input type="Address" class="form-control" id="Material_code" name="Material_code" value="<?= $record['Material_code'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Amount">Amount</label>
                        <input type="text" class="form-control" id="Amount" name="Amount" value="<?= $record['Amount'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Valid_from">Valid_from</label>
                        <input type="Address" class="form-control" id="Valid_from" name="Valid_from" value="<?= $record['Valid_from'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Valid_to">Valid_to </label>
                        <input type="Address" class="form-control" id="Valid_to" name="Valid_to" value="<?= $record['Valid_to'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Status">Status </label>
                        <input type="Address" class="form-control" id="Status" name="Status" value="<?= $record['Status'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Tax">Tax</label>
                        <input type="text" class="form-control" id="Tax" name="Tax" value="<?= $record['Tax'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Tax_value">Tax_value</label>
                        <input type="Address" class="form-control" id="Tax_value" name="Tax_value" value="<?= $record['Tax_value'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Net_price">Net_price </label>
                        <input type="Address" class="form-control" id="Net_price" name="Net_price" value="<?= $record['Net_price'] ?>">
                    </div> 
                            <button type="submit" class="btn btn-primary">Submit</button>
                
                         <!-- <button type="submit" class="btn btn-primary" name="update">Update</button> -->
            </form>
        </div>
    </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f8f9fa;
        }
        .upload-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .upload-container input[type="file"] {
            display: none;
        }
        .upload-container label {
            display: inline-block;
            padding: 10px 20px;
            color: #fff;
            background-color: #007bff;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="upload-container">
    <form action="/upload" method="post" enctype="multipart/form-data">
        <input type="file" id="file" name="file">
        <label for="file">Choose File</label

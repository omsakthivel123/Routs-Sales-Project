<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Record</h2>
        <div class="modal-body">
            <form action="<?= base_url('Tray/update/'.$record['Id']) ?>" method="post">
                    <div class="form-group">
                        <l abel for="Company">Company </label>
                        <input type="text" class="form-control" id="Company" name="Company"  value="<?= $record['Company'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Sales_Area">Sales_Area</label>
                        <input type="text" class="form-control" id="Sales_Area" name="Sales_Area"  value="<?= $record['Sales_Area'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Tray_Code">Tray_Code</label>
                        <input type="text" class="form-control" id="Tray_Code" name="Tray_Code"  value="<?= $record['Tray_Code'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Tray_Description">Tray_Description</label>
                        <input type="Address" class="form-control" id="Tray_Description" name="Tray_Description"  value="<?= $record['Tray_Description'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Type">Type </label>
                        <input type="Address" class="form-control" id="Type" name="Type" value="<?= $record['Type'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Capacity">Capacity </label>
                        <input type="Address" class="form-control" id="Capacity" name="Capacity"  value="<?= $record['Capacity'] ?>">
                    </div> 
                            <button type="submit" class="btn btn-primary">Submit</button>
                
                         <!-- <button type="submit" class="btn btn-primary" name="update">Update</button> -->
            </form>
        </div>
    </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Record</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Record</h2>
        <div class="modal-body">
            <form action="<?= base_url('Supervisor/update/'.$record['Id']) ?>" method="post">
                     <div class="form-group">
                        <label for="Company_Name">Company *</label>
                        <select class="form-control" id="Company_Name" name="Company_Name" value="<?= $record['Company_Name'] ?>">
                            <option value="Selecet Company">Selecet Company</option>
                            <option value="Vijay Home Foods TRICHY(VHFTRY)">Vijay Home Foods TRICHY(VHFTRY)</option>
                            <option value="Vijay Home Foods (P) LTD(VHF)">Vijay Home Foods (P) LTD(VHF)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="Plant_Name">Plant_Name </label>
                        <input type="text" class="form-control" id="Plant_Name" name="Plant_Name" value="<?= $record['Plant_Name'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Sales_Organisation_Name">Sales_Organisation_Name</label>
                        <input type="text" class="form-control" id="Sales_Organisation_Name" name="Sales_Organisation_Name" value="<?= $record['Sales_Organisation_Name'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Supervisor_Code">Supervisor_Code</label>
                        <input type="text" class="form-control" id="Supervisor_Code" name="Supervisor_Code" value="<?= $record['Supervisor_Code'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Employee_Code">Employee_Code</label>
                        <input type="Address" class="form-control" id="Employee_Code" name="Employee_Code" value="<?= $record['Employee_Code'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Supervisor_Name">Supervisor_Name </label>
                        <input type="Address" class="form-control" id="Supervisor_Name" name="Supervisor_Name" value="<?= $record['Supervisor_Name'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Street">Street</label>
                        <input type="text" class="form-control" id="Street" name="Street" value="<?= $record['Street'] ?>">
                    </div> 
                    <div class="form-group">
                        <label for="Address">Address</label>
                        <input type="text" class="form-control" id="Address" name="Address" value="<?= $record['Address'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Postal_Code">Postal_Code</label>
                        <input type="text" class="form-control" id="Postal_Code" name="Postal_Code" value="<?= $record['Postal_Code'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Mobile_Number">Mobile_Number</label>
                        <input type="text" class="form-control" id="Mobile_Number" name="Mobile_Number" value="<?= $record['Mobile_Number'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="City">City</label>
                        <input type="text" class="form-control" id="City" name="City" value="<?= $record['City'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Region">Region</label>
                        <input type="text" class="form-control" id="Region" name="Region" value="<?= $record['Region'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Country	">Country	</label>
                        <input type="text" class="form-control" id="Country	" name="Country" value="<?= $record['Country'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="User_Name">User_Name</label>
                        <input type="text" class="form-control" id="User_Name" name="User_Name" value="<?= $record['User_Name'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Password">Password</label>
                        <input type="text" class="form-control" id="Password" name="Password" value="<?= $record['Password'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Confirm_Password">Confirm_Password</label>
                        <input type="text" class="form-control" id="Confirm_Password" name="Confirm_Password" value="<?= $record['Confirm_Password'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="Status">Status</label>
                        <input type="text" class="form-control" id="Status" name="Status" value="<?= $record['Status'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="ERP_ID">ERP_ID</label>
                        <input type="text" class="form-control" id="ERP_ID" name="ERP_ID" value="<?= $record['ERP_ID'] ?>">
                    </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                
                         <!-- <button type="submit" class="btn btn-primary" name="update">Update</button> -->
            </form>
        </div>
    </div>
    </div>
    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

